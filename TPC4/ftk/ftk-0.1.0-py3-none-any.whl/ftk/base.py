import re
import jjcli

def lexer(txt):
    # FIXME me patters stopwords lems
    return re.findall("\w+|\w+(\-\w+)*|[^\w\s]+",txt) 

def main():
    cl = jjcli.clfilter()
    
    for txt in cl.text():
        print(lexer(txt))
    
    