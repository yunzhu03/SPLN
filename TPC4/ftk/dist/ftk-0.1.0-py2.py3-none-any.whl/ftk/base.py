import re
import jjcli # type: ignore
from collections import Counter

def lexer(txt):
    # FIXME me patters stopwords lems
    return re.findall("\w+|\w+(?:-\w+)+|[^\w\s]+",txt) #?: significa agrupar só sem capturar

def counter(tokens):
    return Counter(tokens)

def main():
    cl = jjcli.clfilter()
    tokens=[]
    for txt in cl.text():
        t=lexer(txt)
        tokens.append(t)
        print(tokens)
    
    